const change = document.getElementById('btn');
const color = document.getElementById('color');
//const body = document.body;

const {body} = document;

change.addEventListener('click', changeBG); //function name only, not full function call i.e != changeBG()

function changeBG() {
    const col1 = getRandomRGB();
    const col2 = getRandomRGB();
    const col3 = getRandomRGB();

    const colorString = `rgb(${col1}, ${col2}, ${col3})`; //this is text formatting

    body.style.background = colorString;
    color.innerText = colorString;
}

function getRandomRGB() {
    return Math.floor(Math.random() * 256);
}