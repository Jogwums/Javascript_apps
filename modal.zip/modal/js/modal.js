// We are targeting three elements in the Js file

const open = document.getElementById('open');
const modal_container = document.getElementById('modal_container');
const close = document.getElementById('close');

//add an event listener on the open button, on click

open.addEventListener('click', () => {
    modal_container.classList.add('show'); //adds this class with its css properties to the button when clicked 
});

close.addEventListener('click', () => {
    modal_container.classList.remove('show');
});